bl_info = {
    "name": "Prismender 1.0.0",
    "author": "Badis DX (reverse-engineered format, built with Claude)",
    "version": (0, 3, 0),
    "blender": (4, 2, 0),  # cible verrouillee : Blender 4.2 LTS uniquement
    "location": "File > Import > Prisma 3D (.prisma)",
    "description": "Importe les scenes/packages Prisma 3D (.prisma) : meshes, materiaux, "
                    "textures, cameras, lumieres, ciel et animations. Cible Blender 4.2 LTS.",
    "category": "Import-Export",
}

import bpy
import os
import json
import struct
import zipfile
import tempfile
import io

# ---------------------------------------------------------------------------
# Decodeur MessagePack "pur Python", sans dependance externe.
# Blender n'embarque pas le module `msgpack`, donc on le reimplemente ici
# (lecture seule, suffisant pour le format Prisma).
# ---------------------------------------------------------------------------

class MsgUnpacker:
    def __init__(self, data: bytes):
        self.data = data
        self.pos = 0
        self.len = len(data)

    def _read(self, n):
        if self.pos + n > self.len:
            raise ValueError("MessagePack: fin de fichier inattendue")
        b = self.data[self.pos:self.pos + n]
        self.pos += n
        return b

    def unpack_one(self):
        b = self._read(1)[0]

        # positive fixint
        if b <= 0x7f:
            return b
        # fixmap
        if 0x80 <= b <= 0x8f:
            return self._unpack_map(b & 0x0f)
        # fixarray
        if 0x90 <= b <= 0x9f:
            return self._unpack_array(b & 0x0f)
        # fixstr
        if 0xa0 <= b <= 0xbf:
            n = b & 0x1f
            return self._read(n).decode("utf-8", errors="replace")
        if b == 0xc0:
            return None
        if b == 0xc2:
            return False
        if b == 0xc3:
            return True
        if b == 0xc4:  # bin8
            n = self._read(1)[0]
            return self._read(n)
        if b == 0xc5:  # bin16
            n = struct.unpack(">H", self._read(2))[0]
            return self._read(n)
        if b == 0xc6:  # bin32
            n = struct.unpack(">I", self._read(4))[0]
            return self._read(n)
        if b == 0xca:  # float32
            return struct.unpack(">f", self._read(4))[0]
        if b == 0xcb:  # float64
            return struct.unpack(">d", self._read(8))[0]
        if b == 0xcc:  # uint8
            return self._read(1)[0]
        if b == 0xcd:  # uint16
            return struct.unpack(">H", self._read(2))[0]
        if b == 0xce:  # uint32
            return struct.unpack(">I", self._read(4))[0]
        if b == 0xcf:  # uint64
            return struct.unpack(">Q", self._read(8))[0]
        if b == 0xd0:  # int8
            return struct.unpack(">b", self._read(1))[0]
        if b == 0xd1:  # int16
            return struct.unpack(">h", self._read(2))[0]
        if b == 0xd2:  # int32
            return struct.unpack(">i", self._read(4))[0]
        if b == 0xd3:  # int64
            return struct.unpack(">q", self._read(8))[0]
        if b == 0xd9:  # str8
            n = self._read(1)[0]
            return self._read(n).decode("utf-8", errors="replace")
        if b == 0xda:  # str16
            n = struct.unpack(">H", self._read(2))[0]
            return self._read(n).decode("utf-8", errors="replace")
        if b == 0xdb:  # str32
            n = struct.unpack(">I", self._read(4))[0]
            return self._read(n).decode("utf-8", errors="replace")
        if b == 0xdc:  # array16
            n = struct.unpack(">H", self._read(2))[0]
            return self._unpack_array(n)
        if b == 0xdd:  # array32
            n = struct.unpack(">I", self._read(4))[0]
            return self._unpack_array(n)
        if b == 0xde:  # map16
            n = struct.unpack(">H", self._read(2))[0]
            return self._unpack_map(n)
        if b == 0xdf:  # map32
            n = struct.unpack(">I", self._read(4))[0]
            return self._unpack_map(n)
        # negative fixint
        if b >= 0xe0:
            return b - 256
        # ext types (d4-d8, c7-c9) : ignores, tres improbable dans ce format
        raise ValueError("MessagePack: octet de type non supporte 0x%02x a l'offset %d" % (b, self.pos - 1))

    def _unpack_array(self, n):
        return [self.unpack_one() for _ in range(n)]

    def _unpack_map(self, n):
        d = {}
        for _ in range(n):
            k = self.unpack_one()
            v = self.unpack_one()
            d[k] = v
        return d

    def unpack_all(self):
        """Le format Prisma serialise une SUITE de valeurs top-level (pas un
        seul array englobant). On depile donc jusqu'a la fin du buffer."""
        items = []
        while self.pos < self.len:
            items.append(self.unpack_one())
        return items


# ---------------------------------------------------------------------------
# Lecture du package .prisma (= ZIP dont le tout premier octet est decale :
# 'P' (0x50) devient 0x60. Le reste de l'archive est un ZIP standard.)
# ---------------------------------------------------------------------------

def open_prisma_zip(filepath):
    with open(filepath, "rb") as f:
        raw = bytearray(f.read())
    if len(raw) < 4:
        raise ValueError("Fichier .prisma vide ou corrompu")
    if raw[0] == 0x60:
        raw[0] = 0x50
    elif raw[0] != 0x50:
        # deja un zip normal, ou format inconnu : on tente quand meme
        pass
    return zipfile.ZipFile(io.BytesIO(bytes(raw)))


def find_project_root(zf):
    """Le contenu est range sous un dossier <guid>/. On le detecte via
    project.proj."""
    for name in zf.namelist():
        if name.endswith("project.proj"):
            return name.rsplit("/", 1)[0]
    raise ValueError("project.proj introuvable dans le package .prisma")


# ---------------------------------------------------------------------------
# Interpretation des valeurs typees Prisma : chaque propriete de composant
# est stockee comme [nom, valeur_str_ou_None, nom_du_type]
# ---------------------------------------------------------------------------

def parse_typed_value(value, typename):
    if value is None:
        return None
    try:
        if typename in ("Vector2", "Vector3", "Vector4", "Color"):
            return json.loads(value)
        if typename in ("Single", "Double", "Float"):
            return float(value)
        if typename in ("Int32", "Int64", "Integer"):
            return int(float(value))
        if typename == "Boolean":
            return value == "True" or value == "true"
        if typename == "PMaterial[]":
            return json.loads(value).get("ids", [])
    except Exception:
        pass
    return value  # chaine brute (enum, nom de shader, chemin de texture...)


def props_to_dict(props):
    """props: liste de [nom, valeur, type] -> dict nom -> valeur decodee."""
    out = {}
    if not props:
        return out
    for p in props:
        if not isinstance(p, list) or len(p) < 3:
            continue
        name, raw_val, typ = p[0], p[1], p[2]
        out[name] = parse_typed_value(raw_val, typ)
    return out


def get_components_dict(components):
    """components: liste de [typeName, props[]] -> dict typeName -> dict props."""
    out = {}
    if not components:
        return out
    for c in components:
        if not isinstance(c, list) or len(c) < 2:
            continue
        ctype, props = c[0], c[1]
        out[ctype] = props_to_dict(props)
    return out


# ---------------------------------------------------------------------------
# Materiaux
# ---------------------------------------------------------------------------

def get_or_create_material(mat_id, materials_by_id, res_dir, cache, warnings):
    if mat_id in cache:
        return cache[mat_id]

    entry = materials_by_id.get(mat_id)
    if entry is None:
        return None  # ex: "default" sans definition explicite -> materiau Blender par defaut

    mat_name = entry[1] if len(entry) > 1 else mat_id
    comp_props = props_to_dict(entry[2]) if len(entry) > 2 else {}

    mat = bpy.data.materials.new(name=mat_name or mat_id)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    bsdf = nodes.get("Principled BSDF")

    color = comp_props.get("color")
    if isinstance(color, dict) and bsdf:
        rgba = (color.get("r", 1.0), color.get("g", 1.0), color.get("b", 1.0), color.get("a", 1.0))
        bsdf.inputs["Base Color"].default_value = rgba

    alpha = comp_props.get("alpha")
    if isinstance(alpha, float) and bsdf:
        if "Alpha" in bsdf.inputs:
            bsdf.inputs["Alpha"].default_value = alpha
        if alpha < 1.0:
            try:
                mat.blend_method = 'BLEND'
            except Exception:
                pass
            try:
                mat.show_transparent_back = False
            except Exception:
                pass

    glossiness = comp_props.get("glossiness")
    if isinstance(glossiness, float) and bsdf and "Roughness" in bsdf.inputs:
        bsdf.inputs["Roughness"].default_value = max(0.0, min(1.0, 1.0 - glossiness))

    specular = comp_props.get("specular")
    if isinstance(specular, float) and bsdf and "Specular IOR Level" in bsdf.inputs:
        bsdf.inputs["Specular IOR Level"].default_value = max(0.0, min(1.0, specular))

    cull_mode = comp_props.get("cullMode")
    if cull_mode is not None:
        try:
            # Blender ne gere qu'un simple on/off de backface culling.
            mat.use_backface_culling = (cull_mode != "Off")
        except Exception:
            pass
        if cull_mode == "Front":
            warnings.add("Materiau '%s' : cullMode='Front' (culling inverse, cote interieur visible) "
                          "— non reproductible exactement dans Blender, backface culling classique applique." % mat_name)

    tex_path = comp_props.get("texture")
    if isinstance(tex_path, str) and tex_path and bsdf:
        clean = tex_path.replace("./", "").replace("\\", "/")
        full_path = os.path.join(res_dir, clean) if res_dir else None
        if full_path and os.path.isfile(full_path):
            img = bpy.data.images.load(full_path, check_existing=True)
            tex_node = nodes.new("ShaderNodeTexImage")
            tex_node.image = img
            tex_node.location = (bsdf.location.x - 300, bsdf.location.y)
            links.new(tex_node.outputs["Color"], bsdf.inputs["Base Color"])
        else:
            warnings.add("Texture introuvable pour materiau '%s' : %s" % (mat_name, tex_path))

    cache[mat_id] = mat
    return mat


# ---------------------------------------------------------------------------
# Geometrie brute (.pobject) : c'est le cas general (objets "template" de
# base Cube/Sphere/Cylindre/Plan/Pyramide, meshes importes, sculpts...).
# Chaque .pobject contient, en plus d'une copie de l'entree "objet", un bloc
# de sous-meshes ou chaque sous-mesh est une liste a 11 champs :
#   [0] id materiau (str)
#   [1] index materiau par face (liste, longueur = nb faces) — non utilise
#       ici car chaque sous-mesh ne porte qu'un seul materiau
#   [2] nb de sommets par face (3=triangle, 4=quad), longueur = nb faces
#   [3] normale par face, longueur = nb faces
#   [4] index de position par coin de face (loop), longueur = total loops
#   [5] UV par loop, longueur = total loops
#   [6] champ non identifie par loop (ignore)
#   [7] triangulation locale par face, pour un renderer qui ne saurait pas
#       gerer les n-gones (Blender les gere nativement -> ignore)
#   [8] positions des sommets uniques (espace local)
#   [9] poids de skinning par sommet (ignore, pas de mesh skinne fourni)
#   [10] champ non identifie (toujours None observe)
# ---------------------------------------------------------------------------

def find_raw_mesh_block(pobject_items):
    """Retrouve, dans le flux msgpack d'un .pobject, la liste de sous-meshes
    (identifiable par sa forme : chaque element est une liste de 11 champs
    dont le premier est une chaine — l'id materiau)."""
    for it in pobject_items:
        if isinstance(it, list) and len(it) > 0 and all(
            isinstance(sm, list) and len(sm) == 11 and isinstance(sm[0], str) for sm in it
        ):
            return it
    return None


def load_raw_mesh_for_object(zf, root, obj_id):
    path = "%s/content/%s.pobject" % (root, obj_id)
    if path not in zf.namelist():
        return None
    data = zf.read(path)
    items = MsgUnpacker(data).unpack_all()
    return find_raw_mesh_block(items)


def apply_auto_smooth(ob, angle_deg=30.0):
    """Blender 4.2 : shading auto-smooth via l'operateur dedie (API introduite
    en 4.1, remplace l'ancien Mesh.use_auto_smooth des versions 3.x)."""
    import math
    bpy.ops.object.shade_auto_smooth(angle=math.radians(angle_deg))


def build_mesh_from_raw(context, obj_name, submeshes, materials_by_id, res_dir, mat_cache, warnings):
    import bmesh

    bm = bmesh.new()
    uv_layer = bm.loops.layers.uv.new("UVMap")

    me = bpy.data.meshes.new(obj_name)
    ob = bpy.data.objects.new(obj_name, me)
    context.collection.objects.link(ob)

    for mat_idx, submesh in enumerate(submeshes):
        (mat_id, _per_face_mat, face_counts, _face_normals,
         loop_pos_idx, loop_uv, _loop_mystery, _tri_fan,
         positions, _skin, _unknown10) = submesh

        mat = get_or_create_material(mat_id, materials_by_id, res_dir, mat_cache, warnings)
        if mat is None:
            mat = mat_cache.get("__default__")
            if mat is None:
                mat = bpy.data.materials.new(name="Prisma_Default")
                mat.use_nodes = True
                mat_cache["__default__"] = mat
            warnings.add("Objet '%s' : materiau '%s' introuvable dans le package "
                          "(probablement un materiau par defaut interne a l'app Prisma 3D) "
                          "— un materiau gris de remplacement a ete utilise." % (obj_name, mat_id))
        me.materials.append(mat)

        # Sommets de ce sous-mesh -> bmesh, avec decalage d'index si plusieurs sous-meshes
        vert_offset = len(bm.verts)
        bm_verts = []
        for p in positions:
            v = bm.verts.new((p[0], p[1], p[2]))
            bm_verts.append(v)
        bm.verts.ensure_lookup_table()

        loop_cursor = 0
        for face_i, vcount in enumerate(face_counts):
            idxs = loop_pos_idx[loop_cursor: loop_cursor + vcount]
            uvs = loop_uv[loop_cursor: loop_cursor + vcount]
            loop_cursor += vcount
            try:
                face_verts = [bm_verts[i] for i in idxs]
                face = bm.faces.new(face_verts)
                face.material_index = mat_idx
                for loop, uv in zip(face.loops, uvs):
                    loop[uv_layer].uv = (uv[0], uv[1])
            except ValueError:
                # face degeneree / deja existante (sommets dupliques) : on l'ignore proprement
                continue

    bm.normal_update()
    bm.to_mesh(me)
    bm.free()
    me.update()

    apply_auto_smooth(ob, 30.0)
    return ob


# ---------------------------------------------------------------------------
# Primitives -> geometrie Blender (repli, quand aucune donnee de mesh brute
# n'est presente dans le .pobject — cas des primitives 100% parametriques)
# ---------------------------------------------------------------------------

def get_vec3(d, default=(1.0, 1.0, 1.0)):
    if isinstance(d, dict):
        return (d.get("x", default[0]), d.get("y", default[1]), d.get("z", default[2]))
    return default


def build_primitive_mesh(context, obj_name, prim_type, prim_props, warnings):
    """Cree l'objet mesh Blender correspondant a une primitive Prisma 3D.
    Box et Torus sont confirmes par les fichiers d'exemple fournis ; les
    autres formes usuelles (Sphere/Cylinder/Cone/Plane) sont mappees de
    facon best-effort et pourront necessiter un ajustement."""

    if prim_type == "Primitives.PrimitiveBox":
        seg = get_vec3(prim_props.get("Segments"), (1.0, 1.0, 1.0))
        bpy.ops.mesh.primitive_cube_add(size=1.0)
        ob = context.active_object
        ob.name = obj_name
        cuts_x, cuts_y, cuts_z = (max(0, int(round(s)) - 1) for s in seg)
        if cuts_x or cuts_y or cuts_z:
            bpy.ops.object.mode_set(mode='EDIT')
            import bmesh
            bm = bmesh.from_edit_mesh(ob.data)
            bmesh.ops.subdivide_edges(
                bm, edges=bm.edges[:], cuts=max(cuts_x, cuts_y, cuts_z), use_grid_fill=True
            )
            bmesh.update_edit_mesh(ob.data)
            bpy.ops.object.mode_set(mode='OBJECT')
        return ob

    if prim_type == "Primitives.PrimitiveTorus":
        radius = prim_props.get("Radius", 0.5)
        width = prim_props.get("Width", 0.2)
        seg = prim_props.get("Segments", {"x": 24, "y": 16})
        major_seg = int(seg.get("x", 24)) if isinstance(seg, dict) else 24
        minor_seg = int(seg.get("y", 16)) if isinstance(seg, dict) else 16
        bpy.ops.mesh.primitive_torus_add(
            major_radius=radius, minor_radius=width,
            major_segments=major_seg, minor_segments=minor_seg,
        )
        ob = context.active_object
        ob.name = obj_name
        return ob

    # Mappings best-effort non confirmes par les fichiers fournis :
    fallback_map = {
        "Primitives.PrimitiveSphere": lambda p: bpy.ops.mesh.primitive_uv_sphere_add(
            radius=p.get("Radius", 0.5)),
        "Primitives.PrimitiveCylinder": lambda p: bpy.ops.mesh.primitive_cylinder_add(
            radius=p.get("Radius", 0.5), depth=p.get("Height", 1.0)),
        "Primitives.PrimitiveCone": lambda p: bpy.ops.mesh.primitive_cone_add(
            radius1=p.get("Radius", 0.5), depth=p.get("Height", 1.0)),
        "Primitives.PrimitivePlane": lambda p: bpy.ops.mesh.primitive_plane_add(size=1.0),
    }
    if prim_type in fallback_map:
        warnings.add("Primitive '%s' importee avec un mapping non verifie (pas d'exemple fourni) — "
                      "verifiez les dimensions." % prim_type)
        fallback_map[prim_type](prim_props)
        ob = context.active_object
        ob.name = obj_name
        return ob

    warnings.add("Type de primitive/geometrie inconnu : '%s' (objet '%s'). "
                  "Importe comme Empty pour conserver la position." % (prim_type, obj_name))
    bpy.ops.object.empty_add(type='PLAIN_AXES')
    ob = context.active_object
    ob.name = obj_name
    return ob


# ---------------------------------------------------------------------------
# Camera (best-effort : aucun exemple avec camera n'a ete fourni pour
# valider les noms exacts de proprietes. On essaie plusieurs alias connus
# de moteurs similaires et on log tout ce qu'on ne reconnait pas.)
# ---------------------------------------------------------------------------

CAMERA_FOV_KEYS = ["fieldOfView", "FieldOfView", "fov", "Fov", "FOV"]
CAMERA_NEAR_KEYS = ["nearClipPlane", "NearClipPlane", "near", "Near", "nearClip"]
CAMERA_FAR_KEYS = ["farClipPlane", "FarClipPlane", "far", "Far", "farClip"]
CAMERA_ORTHO_KEYS = ["orthographic", "Orthographic", "isOrthographic", "IsOrthographic"]
CAMERA_ORTHO_SIZE_KEYS = ["orthographicSize", "OrthographicSize"]
CAMERA_SENSOR_KEYS = ["sensorSize", "SensorSize"]
# Proprietes confirmees par les templates Cam_*.prisma mais volontairement non
# appliquees (pas d'equivalent direct utile a la geometrie/optique de la
# camera Blender) : background (couleur de fond de rendu, globale a la scene
# chez Prisma alors que Blender la gere via le World, pas par camera) et
# gateFit (mode de cadrage du capteur, sans equivalent simple).
CAMERA_KNOWN_UNAPPLIED_KEYS = ["background", "Background", "gateFit", "GateFit"]


def build_camera(context, obj_name, cam_props, warnings):
    cam_data = bpy.data.cameras.new(obj_name)
    ob = bpy.data.objects.new(obj_name, cam_data)
    context.collection.objects.link(ob)

    def first_present(keys):
        for k in keys:
            if k in cam_props:
                return cam_props[k]
        return None

    fov = first_present(CAMERA_FOV_KEYS)
    if fov is not None:
        try:
            import math
            # Prisma (comme Unity) exprime le FOV verticalement : on force
            # sensor_fit='VERTICAL' pour que cam_data.angle soit interprete
            # de la meme facon dans Blender.
            cam_data.sensor_fit = 'VERTICAL'
            cam_data.lens_unit = 'FOV'
            cam_data.angle = math.radians(float(fov))
        except Exception:
            pass

    near = first_present(CAMERA_NEAR_KEYS)
    if near is not None:
        try:
            cam_data.clip_start = max(1e-5, float(near))
        except Exception:
            pass

    far = first_present(CAMERA_FAR_KEYS)
    if far is not None:
        try:
            cam_data.clip_end = float(far)
        except Exception:
            pass

    ortho = first_present(CAMERA_ORTHO_KEYS)
    if ortho:
        cam_data.type = 'ORTHO'
        ortho_size = first_present(CAMERA_ORTHO_SIZE_KEYS)
        if ortho_size is not None:
            try:
                # Unity/Prisma "orthographicSize" = demi-hauteur de la vue ;
                # Blender "ortho_scale" = hauteur totale -> facteur 2.
                # (approximation raisonnable, a ajuster visuellement si besoin)
                cam_data.ortho_scale = float(ortho_size) * 2.0
            except Exception:
                pass

    sensor = first_present(CAMERA_SENSOR_KEYS)
    if isinstance(sensor, dict) and sensor.get("x", 0) and sensor.get("y", 0):
        try:
            cam_data.sensor_width = float(sensor["x"])
            cam_data.sensor_height = float(sensor["y"])
        except Exception:
            pass

    known = set(
        CAMERA_FOV_KEYS + CAMERA_NEAR_KEYS + CAMERA_FAR_KEYS + CAMERA_ORTHO_KEYS
        + CAMERA_ORTHO_SIZE_KEYS + CAMERA_SENSOR_KEYS + CAMERA_KNOWN_UNAPPLIED_KEYS
    )
    unknown_props = {k: v for k, v in cam_props.items() if k not in known}
    if unknown_props:
        warnings.add(
            "Camera '%s' : proprietes non reconnues -> %s."
            % (obj_name, list(unknown_props.keys()))
        )
    return ob


LIGHT_TYPE_MAP = {
    "Point": "POINT",
    "Spot": "SPOT",
    "Directional": "SUN",
    "Area": "AREA",
}

LIGHT_COLOR_KEYS = ["color", "Color"]
LIGHT_INTENSITY_KEYS = ["intensity", "Intensity"]
LIGHT_RANGE_KEYS = ["Range", "range"]
LIGHT_ANGLE_KEYS = ["Angle", "angle"]  # pertinent surtout pour les spots
LIGHT_SHADOW_KEYS = ["Shadow", "shadow"]


def build_light(context, obj_name, light_props, warnings):
    def first_present(keys):
        for k in keys:
            if k in light_props:
                return light_props[k]
        return None

    prisma_type = light_props.get("lightType", "Point")
    blender_type = LIGHT_TYPE_MAP.get(prisma_type)
    if blender_type is None:
        warnings.add("Lumiere '%s' : type '%s' non reconnu, importee comme POINT par defaut." % (obj_name, prisma_type))
        blender_type = 'POINT'

    light_data = bpy.data.lights.new(obj_name, type=blender_type)
    ob = bpy.data.objects.new(obj_name, light_data)
    context.collection.objects.link(ob)

    color = first_present(LIGHT_COLOR_KEYS)
    if isinstance(color, dict):
        light_data.color = (color.get("r", 1.0), color.get("g", 1.0), color.get("b", 1.0))

    # Conversion approximative de l'intensite Prisma (unitless, proche de la
    # convention Unity) vers les Watts Blender : il n'existe pas de
    # correspondance physique exacte entre les deux moteurs. Le facteur
    # utilise ici (x1000 pour Point/Spot) donne un rendu visuellement proche ;
    # ajustez manuellement l'energie si besoin.
    intensity = first_present(LIGHT_INTENSITY_KEYS)
    if intensity is not None:
        try:
            intensity = float(intensity)
            if blender_type == 'SUN':
                light_data.energy = intensity  # Sun se mesure en W/m2, plus proche de l'unite d'origine
            else:
                light_data.energy = intensity * 1000.0
            warnings.add("Lumiere '%s' : intensite convertie avec un facteur approximatif "
                          "(Prisma et Blender n'utilisent pas la meme unite photometrique) — "
                          "ajustez l'energie si le rendu est trop clair/sombre." % obj_name)
        except Exception:
            pass

    rng = first_present(LIGHT_RANGE_KEYS)
    if rng is not None and blender_type in ('POINT', 'SPOT'):
        try:
            light_data.use_custom_distance = True
            light_data.cutoff_distance = float(rng)
        except Exception:
            pass

    if blender_type == 'SPOT':
        angle = first_present(LIGHT_ANGLE_KEYS)
        if angle is not None:
            try:
                import math
                # "Angle" chez Prisma correspond a l'angle TOTAL du cone
                # (comme Unity spotAngle), identique a la convention de
                # spot_size de Blender -> conversion directe, sans x2.
                light_data.spot_size = math.radians(float(angle))
            except Exception:
                pass

    shadow = first_present(LIGHT_SHADOW_KEYS)
    if shadow is not None:
        try:
            shadow_f = float(shadow)
            light_data.use_shadow = shadow_f > 0.0
            if 0.0 < shadow_f < 1.0:
                warnings.add("Lumiere '%s' : Shadow=%.3g (intensite d'ombre partielle) — "
                              "Blender ne propose qu'un on/off par lumiere, ombre activee." % (obj_name, shadow_f))
        except Exception:
            pass

    known = set(
        ["lightType"] + LIGHT_COLOR_KEYS + LIGHT_INTENSITY_KEYS + LIGHT_RANGE_KEYS
        + LIGHT_ANGLE_KEYS + LIGHT_SHADOW_KEYS
    )
    unknown_props = {k: v for k, v in light_props.items() if k not in known}
    if unknown_props:
        warnings.add("Lumiere '%s' : proprietes non reconnues -> %s." % (obj_name, list(unknown_props.keys())))

    return ob


# ---------------------------------------------------------------------------
# Ciel (PSky) : affecte le World de la scene Blender plutot qu'un objet
# visible. On cree neanmoins un Empty au meme nom pour garder une trace
# coherente dans le contenu importe.
# ---------------------------------------------------------------------------

def build_sky(context, obj_name, sky_props, res_dir, sky_top_color, sky_bottom_color, warnings):
    world = context.scene.world
    if world is None:
        world = bpy.data.worlds.new("Prisma_World")
        context.scene.world = world
    world.use_nodes = True
    nodes = world.node_tree.nodes
    links = world.node_tree.links
    bg = nodes.get("Background")

    intensity = sky_props.get("Intensity", 1.0) or 1.0
    exposure = sky_props.get("SkyboxExposure", 1.0) or 1.0
    try:
        strength = float(intensity) * float(exposure)
    except Exception:
        strength = 1.0

    skybox_path = sky_props.get("Skybox")
    is_timed = sky_props.get("IsTimedSkybox", False)

    if isinstance(skybox_path, str) and skybox_path and res_dir:
        clean = skybox_path.replace("./", "").replace("\\", "/")
        full_path = os.path.join(res_dir, clean)
        if os.path.isfile(full_path):
            img = bpy.data.images.load(full_path, check_existing=True)
            env_node = nodes.new("ShaderNodeTexEnvironment")
            env_node.image = img
            env_node.location = (bg.location.x - 500, bg.location.y)

            angle = sky_props.get("Angle", 0.0) or 0.0
            coord = nodes.new("ShaderNodeTexCoord")
            mapping = nodes.new("ShaderNodeMapping")
            coord.location = (env_node.location.x - 400, env_node.location.y)
            mapping.location = (env_node.location.x - 200, env_node.location.y)
            try:
                import math
                mapping.inputs["Rotation"].default_value = (0.0, 0.0, math.radians(float(angle)))
            except Exception:
                pass
            links.new(coord.outputs["Generated"], mapping.inputs["Vector"])
            links.new(mapping.outputs["Vector"], env_node.inputs["Vector"])
            links.new(env_node.outputs["Color"], bg.inputs["Color"])
        else:
            warnings.add("Ciel '%s' : texture de skybox introuvable : %s" % (obj_name, skybox_path))
    else:
        # Pas de texture (ciel procedural "timed") : on approxime avec un
        # degrade simple entre les deux couleurs de ciel de la scene
        # (haut/bas), qui refletent deja l'heure du jour choisie dans Prisma.
        grad = nodes.new("ShaderNodeTexGradient")
        grad.gradient_type = 'LINEAR'
        ramp = nodes.new("ShaderNodeValToRGB")
        coord = nodes.new("ShaderNodeTexCoord")
        grad.location = (bg.location.x - 500, bg.location.y)
        ramp.location = (bg.location.x - 300, bg.location.y)
        coord.location = (bg.location.x - 700, bg.location.y)
        if sky_bottom_color:
            ramp.color_ramp.elements[0].color = tuple(sky_bottom_color)
        if sky_top_color:
            ramp.color_ramp.elements[1].color = tuple(sky_top_color)
        links.new(coord.outputs["Generated"], grad.inputs["Vector"])
        links.new(grad.outputs["Fac"], ramp.inputs["Fac"])
        links.new(ramp.outputs["Color"], bg.inputs["Color"])
        if is_timed:
            warnings.add("Ciel '%s' : ciel procedural 'timed' de Prisma approxime par un simple "
                          "degrade de couleurs (le calcul precis du soleil/heure n'est pas reproduit)." % obj_name)

    try:
        bg.inputs["Strength"].default_value = strength
    except Exception:
        pass

    known = {"TimeOfDay", "Intensity", "Shadow", "Skybox", "SkyboxExposure", "IsTimedSkybox", "Angle"}
    unknown_props = {k: v for k, v in sky_props.items() if k not in known}
    if unknown_props:
        warnings.add("Ciel '%s' : proprietes non reconnues -> %s." % (obj_name, list(unknown_props.keys())))

    bpy.ops.object.empty_add(type='PLAIN_AXES')
    ob = context.active_object
    ob.name = obj_name
    ob.empty_display_size = 0.3
    return ob


# ---------------------------------------------------------------------------
# Animations (.pclip) : courbes d'animation par propriete, au format tres
# proche d'un AnimationClip Unity. Chaque .pclip contient un dict de courbes
# indexees par "idObjet/composant.propriete", chaque courbe etant
# [ [canalX, canalY, canalZ...], None ] et chaque canal
# [ [ [temps, valeur, tangenteIn, tangenteOut, modePondere, poidsIn, poidsOut], ... ], preWrap, postWrap ].
# Les temps sont en SECONDES (a convertir en frames via le fps du projet).
# ---------------------------------------------------------------------------

def parse_pclip(zf, path):
    data = zf.read(path)
    items = MsgUnpacker(data).unpack_all()
    # Les premiers champs (apres version+hash) encodent parfois l'id du clip
    # caractere par caractere (bizarrerie du serialiseur) ; le premier champ
    # de type string rencontre est donc le NOM du clip, pas son id.
    name_idx = None
    for i in range(2, len(items)):
        if isinstance(items[i], str):
            name_idx = i
            break
    if name_idx is None or name_idx + 1 >= len(items):
        return None
    curves = items[name_idx + 1]
    duration = items[name_idx + 2] if name_idx + 2 < len(items) else None
    return {"name": items[name_idx], "curves": curves, "duration": duration}


ANIM_PROPERTY_ROUTES = {
    "transform.localPosition": ("OBJECT", "location", False, 1.0),
    "transform.localEulerAnglesHint": ("OBJECT", "rotation_euler", True, 1.0),
    "transform.localScale": ("OBJECT", "scale", False, 1.0),
    "camera.fieldOfView": ("DATA", "angle", True, 1.0),
    "light.color": ("DATA", "color", False, 1.0),
    # light.intensity : facteur applique dynamiquement (POINT/SPOT vs SUN), voir plus bas
    "light.Range": ("DATA", "cutoff_distance", False, 1.0),
    "light.Angle": ("DATA", "spot_size", True, 1.0),
}
# Proprietes reconnues mais volontairement non animees (memes limites que
# pour l'import statique : pas d'equivalent Blender pertinent / booleen
# uniquement, non interpolable proprement).
ANIM_PROPERTY_SKIP = {"light.Shadow", "camera.background"}


def get_or_create_action(id_block, name):
    if id_block.animation_data is None:
        id_block.animation_data_create()
    if id_block.animation_data.action is None:
        id_block.animation_data.action = bpy.data.actions.new(name)
    return id_block.animation_data.action


def add_fcurve_from_channel(action, data_path, index, channel, fps, value_scale=1.0):
    if not channel or not channel[0]:
        return
    keyframes = channel[0]
    fcurve = action.fcurves.find(data_path, index=index)
    if fcurve is None:
        fcurve = action.fcurves.new(data_path, index=index)
    existing = len(fcurve.keyframe_points)
    fcurve.keyframe_points.add(len(keyframes))
    for i, kf in enumerate(keyframes):
        t, val = kf[0], kf[1]
        frame = t * fps + 1.0
        kp = fcurve.keyframe_points[existing + i]
        kp.co = (frame, val * value_scale)
        kp.interpolation = 'BEZIER'
        kp.handle_left_type = 'AUTO_CLAMPED'
        kp.handle_right_type = 'AUTO_CLAMPED'
    fcurve.update()


def apply_clip_animation(context, id_to_object, clip, fps, warnings):
    if not clip or not isinstance(clip.get("curves"), dict):
        return
    import math

    for full_key, curve_value in clip["curves"].items():
        if "/" not in full_key:
            continue
        obj_id, prop = full_key.split("/", 1)
        ob = id_to_object.get(obj_id)
        if ob is None:
            continue  # objet non importe (ne devrait pas arriver, mais on reste defensif)

        if prop in ANIM_PROPERTY_SKIP:
            warnings.add("Animation de '%s' sur '%s' : non reproduite (pas d'equivalent Blender adapte)."
                         % (prop, ob.name))
            continue

        if not isinstance(curve_value, list) or not curve_value or not isinstance(curve_value[0], list):
            continue
        channels_list = curve_value[0]

        if prop == "light.intensity":
            if ob.data is None:
                continue
            scale = 1.0 if getattr(ob.data, "type", "") == 'SUN' else 1000.0
            action = get_or_create_action(ob.data, ob.name + "_data")
            add_fcurve_from_channel(action, "energy", 0, channels_list[0], fps, value_scale=scale)
            warnings.add("Animation de l'intensite de '%s' : convertie avec le meme facteur "
                          "approximatif que l'import statique — ajustez si besoin." % ob.name)
            continue

        route = ANIM_PROPERTY_ROUTES.get(prop)
        if route is None:
            warnings.add("Animation : propriete non reconnue '%s' sur l'objet id %s (ignoree)." % (prop, obj_id))
            continue

        target_kind, data_path, is_angle, _unused = route
        if target_kind == "OBJECT":
            target = ob
            action = get_or_create_action(target, ob.name)
        else:
            if ob.data is None:
                continue
            target = ob.data
            action = get_or_create_action(target, ob.name + "_data")

        for idx, chan in enumerate(channels_list):
            if is_angle and chan and chan[0]:
                # Conversion degres -> radians des valeurs uniquement (les
                # tangentes d'origine ne sont de toute facon pas reutilisees :
                # voir AUTO_CLAMPED dans add_fcurve_from_channel).
                chan = [[[kf[0], math.radians(kf[1])] for kf in chan[0]]] + list(chan[1:])
            add_fcurve_from_channel(action, data_path, idx, chan, fps)


def import_animations(context, zf, root, id_to_object, project_fps, warnings):
    clip_paths = [n for n in zf.namelist() if n.startswith(root + "/clip/") and n.endswith(".pclip")]
    if not clip_paths:
        return
    max_duration = 0.0
    for cp in clip_paths:
        clip = parse_pclip(zf, cp)
        if clip is None:
            warnings.add("Fichier d'animation illisible : %s" % cp)
            continue
        apply_clip_animation(context, id_to_object, clip, project_fps, warnings)
        if isinstance(clip.get("duration"), (int, float)):
            max_duration = max(max_duration, clip["duration"])

    try:
        context.scene.render.fps = int(round(project_fps)) if project_fps else 30
    except Exception:
        pass
    if max_duration > 0:
        try:
            context.scene.frame_end = max(context.scene.frame_end, int(round(max_duration * project_fps)) + 1)
        except Exception:
            pass

    warnings.add("Animations importees : temps et valeurs de chaque keyframe sont fideles a Prisma 3D, "
                  "mais les tangentes/easing exactes sont approximees par des poignees Bezier automatiques.")


# ---------------------------------------------------------------------------
# Import principal
# ---------------------------------------------------------------------------

def import_prisma(context, filepath, warnings):
    zf = open_prisma_zip(filepath)
    root = find_project_root(zf)

    proj_path = root + "/project.proj"
    data = zf.read(proj_path)
    items = MsgUnpacker(data).unpack_all()

    if len(items) < 14:
        raise ValueError("project.proj : structure inattendue (%d champs, 14+ attendus). "
                          "Le format a peut-etre change." % len(items))

    objects_raw = items[11]
    materials_raw = items[12]
    cameras_raw = items[13] if len(items) > 13 else []
    sky_top_color = items[7] if len(items) > 7 else None
    sky_bottom_color = items[8] if len(items) > 8 else None

    materials_by_id = {m[0]: m for m in materials_raw if isinstance(m, list) and m}

    # Extraction des ressources (textures) dans un dossier temporaire
    res_dir = None
    res_prefix = root + "/res/"
    res_names = [n for n in zf.namelist() if n.startswith(res_prefix) and not n.endswith("/")]
    if res_names:
        res_dir_base = tempfile.mkdtemp(prefix="prisma3d_import_")
        res_dir = os.path.join(res_dir_base, "res")
        os.makedirs(res_dir, exist_ok=True)
        for n in res_names:
            out_path = os.path.join(res_dir, os.path.relpath(n, res_prefix))
            os.makedirs(os.path.dirname(out_path), exist_ok=True)
            with open(out_path, "wb") as f:
                f.write(zf.read(n))

    project_name = os.path.splitext(os.path.basename(filepath))[0]
    collection = bpy.data.collections.new(project_name)
    context.scene.collection.children.link(collection)

    prev_active_collection = context.view_layer.active_layer_collection
    layer_coll = None
    for lc in context.view_layer.layer_collection.children:
        if lc.collection == collection:
            layer_coll = lc
            break
    if layer_coll:
        context.view_layer.active_layer_collection = layer_coll

    mat_cache = {}
    id_to_object = {}

    for entry in objects_raw:
        if not isinstance(entry, list) or len(entry) < 3:
            continue
        obj_id = entry[0]
        obj_name = entry[1] or obj_id
        components = get_components_dict(entry[2])

        transform = components.get("PTransform", {})
        pos = get_vec3(transform.get("localPosition"), (0.0, 0.0, 0.0))
        rot_hint = get_vec3(transform.get("localEulerAnglesHint"), (0.0, 0.0, 0.0))
        scale = get_vec3(transform.get("localScale"), (1.0, 1.0, 1.0))

        # Recherche du composant "forme" (primitive) parmi les composants connus
        prim_type = None
        for ctype in components:
            if ctype.startswith("Primitives."):
                prim_type = ctype
                break

        mesh_renderer = components.get("PMeshRenderer", {})

        raw_mesh = load_raw_mesh_for_object(zf, root, obj_id)

        if "PCamera" in components or "Camera" in components:
            cam_props = components.get("PCamera", components.get("Camera", {}))
            ob = build_camera(context, obj_name, cam_props, warnings)
        elif "PLight" in components or "Light" in components:
            light_props = components.get("PLight", components.get("Light", {}))
            ob = build_light(context, obj_name, light_props, warnings)
        elif "PSky" in components:
            sky_props = components.get("PSky", {})
            ob = build_sky(context, obj_name, sky_props, res_dir, sky_top_color, sky_bottom_color, warnings)
        elif raw_mesh:
            # Cas general : geometrie brute presente dans le .pobject
            # (objets de base Cube/Sphere/Cylindre/Plan/Pyramide, meshes
            # importes, sculpts...). Prioritaire sur la reconstruction
            # procedurale ci-dessous.
            ob = build_mesh_from_raw(context, obj_name, raw_mesh, materials_by_id, res_dir, mat_cache, warnings)
        elif prim_type:
            ob = build_primitive_mesh(context, obj_name, prim_type, components.get(prim_type, {}), warnings)
            # Assignation du/des materiau(x)
            mat_ids = mesh_renderer.get("materials")
            if isinstance(mat_ids, list) and ob.data and hasattr(ob.data, "materials"):
                for mid in mat_ids:
                    mat = get_or_create_material(mid, materials_by_id, res_dir, mat_cache, warnings)
                    if mat:
                        ob.data.materials.append(mat)
        else:
            warnings.add("Objet '%s' : aucun composant de geometrie/camera reconnu (composants presents: %s). "
                          "Importe comme Empty." % (obj_name, list(components.keys())))
            bpy.ops.object.empty_add(type='PLAIN_AXES')
            ob = context.active_object
            ob.name = obj_name

        # Deplacement de l'objet dans la bonne collection
        for c in list(ob.users_collection):
            c.objects.unlink(ob)
        collection.objects.link(ob)

        ob.location = pos
        ob.scale = scale
        try:
            import math
            ob.rotation_euler = tuple(math.radians(a) for a in rot_hint)
        except Exception:
            pass

        id_to_object[obj_id] = ob

    if layer_coll and prev_active_collection:
        context.view_layer.active_layer_collection = prev_active_collection

    project_fps = items[3] if len(items) > 3 and isinstance(items[3], (int, float)) else 30
    import_animations(context, zf, root, id_to_object, project_fps, warnings)

    return id_to_object


# ---------------------------------------------------------------------------
# Operateur Blender + enregistrement
# ---------------------------------------------------------------------------

class IMPORT_OT_prisma3d(bpy.types.Operator):
    bl_idname = "import_scene.prisma3d"
    bl_label = "Import Prisma 3D (.prisma)"
    bl_description = "Importe un package de scene Prisma 3D"
    bl_options = {'REGISTER', 'UNDO'}

    filepath: bpy.props.StringProperty(subtype='FILE_PATH')
    filter_glob: bpy.props.StringProperty(default="*.prisma", options={'HIDDEN'})

    def execute(self, context):
        warnings = set()
        try:
            import_prisma(context, self.filepath, warnings)
        except Exception as e:
            self.report({'ERROR'}, "Echec de l'import Prisma 3D : %s" % e)
            return {'CANCELLED'}

        for w in warnings:
            self.report({'WARNING'}, w)
        self.report({'INFO'}, "Import Prisma 3D termine (%s avertissement(s))." % len(warnings))
        return {'FINISHED'}

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


def menu_func_import(self, context):
    self.layout.operator(IMPORT_OT_prisma3d.bl_idname, text="Prisma 3D (.prisma)")


def register():
    bpy.utils.register_class(IMPORT_OT_prisma3d)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)


def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.utils.unregister_class(IMPORT_OT_prisma3d)


if __name__ == "__main__":
    register()
